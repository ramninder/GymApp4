package com.example.gym;

import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class NearByGymActivity extends AppCompatActivity implements GymAdapter.Callback {

    @BindView(R.id.mRecyclerView)
    RecyclerView mRecyclerView;
    GymAdapter mSportAdapter;
    RelativeLayout backBtn;
    LinearLayoutManager mLayoutManager;
    List<NearByGymPojo> byGymPojoList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_near_by_gym);
        ButterKnife.bind(this);
        RealmManager.open();
        setUp();
        backBtn = findViewById(R.id.backBtn);
        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    private void loadFromDB() {
        byGymPojoList = new ArrayList<>();
        byGymPojoList.clear();
        byGymPojoList = RealmManager.recordsDao().fetchGymLocations();
    }

    private void setUp() {
        loadFromDB();
        mLayoutManager = new LinearLayoutManager(this);
        mLayoutManager.setOrientation(RecyclerView.VERTICAL);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        Drawable dividerDrawable = ContextCompat.getDrawable(this, R.drawable.divider_gym);
        mRecyclerView.addItemDecoration(new DividerItemDecoration(dividerDrawable));
        mSportAdapter = new GymAdapter(new ArrayList<>());

        prepareDemoContent();
    }

    @Override
    public void onDestroy() {
        RealmManager.close();
        super.onDestroy();
    }

    private void prepareDemoContent() {
        CommonUtils.showLoading(NearByGymActivity.this);
        new Handler().postDelayed(() -> {
            //prepare data and show loading
            CommonUtils.hideLoading();
            ArrayList<GymPojo> mGym = new ArrayList<>();

            for (int i = 0; i < byGymPojoList.size(); i++) {
                mGym.add(new GymPojo("", byGymPojoList.get(i).getAddress(),
                        "Gym",
                        byGymPojoList.get(i).getGymName()));
            }
            mSportAdapter.addItems(mGym);
            mRecyclerView.setAdapter(mSportAdapter);
        }, 2000);


    }

    @Override
    public void onEmptyViewRetryClick() {
        prepareDemoContent();
    }
}
