package com.example.gym;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class GymOnlineAdapter extends RecyclerView.Adapter<GymOnlineAdapter.ViewHolder> {
    private ArrayList<ResponseGym> listdata;
    Context context;


    public GymOnlineAdapter(Context context, ArrayList<ResponseGym> listdata) {
        this.listdata = listdata;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem = layoutInflater.inflate(R.layout.item_data, parent, false);
        ViewHolder viewHolder = new ViewHolder(listItem);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        final ResponseGym responseGym = listdata.get(position);
        holder.tvPlaceName.setText(responseGym.getPlaceName());
        holder.tvAddress.setText(responseGym.getAddress());
        holder.tvRatting.setText("Rating: " + responseGym.getRatting());
        holder.tvUserRatting.setText("Total User Ratings: " + responseGym.getPeopleRatting());
        Log.e("getImageUrl:", "" + responseGym.getImageUrl());
        Glide.with(context)
                .load(responseGym.getImageUrl())
                .into(holder.ivLogo);
        holder.fmClick.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NearByGymGoogleApiActivity.ratting = responseGym.getRatting();
                NearByGymGoogleApiActivity.total_user_ratting = responseGym.getPeopleRatting();
                NearByGymGoogleApiActivity.gymName = responseGym.getPlaceName();
                NearByGymGoogleApiActivity.gymImageUrl = responseGym.getImageUrl();
                NearByGymGoogleApiActivity.gymAddress = responseGym.getAddress();

                Intent intent = new Intent(context, GymReviewActivity.class);
                context.startActivity(intent);
            }
        });

    }


    @Override
    public int getItemCount() {
        return listdata.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView ivLogo;
        public TextView tvPlaceName, tvAddress, tvRatting, tvUserRatting;
        FrameLayout fmClick;


        public ViewHolder(View itemView) {
            super(itemView);
            this.ivLogo = itemView.findViewById(R.id.ivLogo);
            this.tvPlaceName = itemView.findViewById(R.id.tvPlaceName);
            this.tvAddress = itemView.findViewById(R.id.tvAddress);
            this.tvRatting = itemView.findViewById(R.id.tvRatting);
            this.tvUserRatting = itemView.findViewById(R.id.tvUserRatting);
            this.fmClick = itemView.findViewById(R.id.fmClick);

        }
    }
}