package com.example.gym;


import androidx.annotation.NonNull;

import java.util.List;

import io.realm.Realm;
import io.realm.RealmQuery;
import io.realm.RealmResults;

public class GymDao {

    private Realm mRealm;
    private RealmQuery<GymProfileData> profileDataSave;
    private RealmQuery<GymLocationData> gymLocationDataRealmQuery;

    public RealmQuery<GymProfileData> loadGymProfileData() {
        profileDataSave=mRealm.where(GymProfileData.class);
        return profileDataSave;
    }

    public void updateSaveProfileGym(GymProfileData profileDataSave) {
        mRealm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                mRealm.copyToRealmOrUpdate(profileDataSave);
            }
        });
    }

    public void locationGym(GymLocationData gymLocationData) {
        mRealm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                mRealm.copyToRealmOrUpdate(gymLocationData);
            }
        });
    }

    public void saveLocations(final List<NearByGymPojo> gymPojoList) {
        mRealm.executeTransaction(new Realm.Transaction() {
            @Override
            public void execute(Realm realm) {
                mRealm.copyToRealmOrUpdate(gymPojoList);
            }
        });
    }
    public RealmResults<NearByGymPojo> fetchGymLocations() {
        return mRealm.where(NearByGymPojo.class).findAllSorted("id");
    }
    public RealmQuery<GymLocationData> loadGymLocation() {
        gymLocationDataRealmQuery=mRealm.where(GymLocationData.class);
        return gymLocationDataRealmQuery;
    }

    GymDao(@NonNull Realm realm) {
        mRealm = realm;
    }

}
