package com.example.gym;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class MenuFragment extends Fragment {
    private FrameLayout flNearByGym,flPayment,flProfile;

    public MenuFragment(){

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_menu,container,false);

        flNearByGym = view.findViewById(R.id.flNearByGym);

        flNearByGym.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // Intent intent = new Intent(getActivity(),NearByGymActivity.class);
                Intent intent = new Intent(getActivity(),NearByGymGoogleApiActivity.class);
                startActivity(intent);
            }
        });

        flPayment = view.findViewById(R.id.flPayment);

        flPayment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(),PaymentActivity.class);
                startActivity(intent);
            }
        });

        flProfile= view.findViewById(R.id.flProfile);
        flProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getActivity(), ProfileActivity.class);
                startActivity(intent);

            }
        });
        return view;

    }
}
