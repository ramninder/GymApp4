package com.example.gym;

import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.facebook.drawee.backends.pipeline.Fresco;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.MultiplePermissionsReport;
import com.karumi.dexter.PermissionToken;
import com.karumi.dexter.listener.DexterError;
import com.karumi.dexter.listener.PermissionRequest;
import com.karumi.dexter.listener.PermissionRequestErrorListener;
import com.karumi.dexter.listener.multi.MultiplePermissionsListener;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;
import java.util.List;
import java.util.Objects;

import de.hdodenhof.circleimageview.CircleImageView;
import io.realm.RealmQuery;

public class ProfileActivity extends AppCompatActivity {

    RelativeLayout backBtn;
    private RealmQuery<GymProfileData> gymProfileDataRealmQuery = null;

    private static final String IMAGE_DIRECTORY = "/GYM";
    private int GALLERY = 1, CAMERA = 2;
    Button btGymSave;
    CircleImageView profileImageGym;
    EditText edFirstName,editTextLastName,edEmail,edDob,edContact;

    private String imagePathGymProfile = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Fresco.initialize(this);
        setContentView(R.layout.activity_profile);
        RealmManager.open();
        backBtn = findViewById(R.id.backBtn);
        edFirstName=findViewById(R.id.edFirstName);
        editTextLastName=findViewById(R.id.editTextLastName);
        edEmail=findViewById(R.id.edEmail);
        edDob=findViewById(R.id.edDob);
        edContact=findViewById(R.id.edContact);

        backBtn.setOnClickListener(view -> finish());
        requestMultipleGYMPermissions();

        profileImageGym = findViewById(R.id.profileImage);
        profileImageGym.setOnClickListener(view -> showPictureGymDialog());

        btGymSave = findViewById(R.id.btGymSave);
        btGymSave.setOnClickListener(view -> {
            GymProfileData gymProfileData=new GymProfileData();
            gymProfileData.setId("1");
            gymProfileData.setmFirstName(edFirstName.getText().toString());
            gymProfileData.setmLastName(editTextLastName.getText().toString());
            gymProfileData.setmEmail(edEmail.getText().toString());
            gymProfileData.setmDOB(edDob.getText().toString());
            gymProfileData.setmAddress(edContact.getText().toString());
            if (imagePathGymProfile != null) {
                gymProfileData.setmImageUrl(imagePathGymProfile);
            }
            saveUpdateGymProfile(gymProfileData);
            Toast.makeText(this, "Gym Profile Successfully Saved.", Toast.LENGTH_SHORT).show();
        });

        gymProfileDataRealmQuery = RealmManager.recordsDao().loadGymProfileData();
        if (gymProfileDataRealmQuery.count() == 1){
            btGymSave.setText(getResources().getString(R.string.string_update));
            GymProfileData profileData=gymProfileDataRealmQuery.findFirst();
            edFirstName.setText(profileData.getmFirstName());
            editTextLastName.setText(profileData.getmLastName());
            edEmail.setText(profileData.getmEmail());
            edDob.setText(profileData.getmDOB());
            edContact.setText(profileData.getmAddress());
            if (profileData.getmImageUrl() != null) {
                Bitmap bitmap = BitmapFactory.decodeFile(profileData.getmImageUrl());
                profileImageGym.setImageBitmap(bitmap);
            }
        }
        else {
            btGymSave.setText(getResources().getString(R.string.save));
        }
    }

    private void showPictureGymDialog() {
        AlertDialog.Builder pictureDialog = new AlertDialog.Builder(this);
        pictureDialog.setTitle("Select Action");
        String[] pictureDialogItems = {
                "Select photo from gallery",
                "Capture photo from camera"};
        pictureDialog.setItems(pictureDialogItems,
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        switch (which) {
                            case 0:
                                choosePhotoFromGallaryGym();
                                break;
                            case 1:
                                takePhotoFromCameraGym();
                                break;
                        }
                    }
                });
        pictureDialog.show();
    }
    private void requestMultipleGYMPermissions() {
        Dexter.withActivity(this)
                .withPermissions(
                        Manifest.permission.CAMERA,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.READ_EXTERNAL_STORAGE)
                .withListener(new MultiplePermissionsListener() {
                    @Override
                    public void onPermissionsChecked(MultiplePermissionsReport report) {
                        // check if all permissions are granted
                        if (report.areAllPermissionsGranted()) {
                           // Toast.makeText(ProfileActivity.this, "All permissions are granted by user!", Toast.LENGTH_SHORT).show();
                        }

                        // check for permanent denial of any permission
                        if (report.isAnyPermissionPermanentlyDenied()) {
                            // show alert dialog navigating to Settings
                            //openSettingsDialog();
                        }
                    }

                    @Override
                    public void onPermissionRationaleShouldBeShown(List<PermissionRequest> permissions, PermissionToken token) {
                        token.continuePermissionRequest();
                    }
                }).
                withErrorListener(new PermissionRequestErrorListener() {
                    @Override
                    public void onError(DexterError error) {
                        Toast.makeText(ProfileActivity.this, "Some Error! ", Toast.LENGTH_SHORT).show();
                    }
                })
                .onSameThread()
                .check();
    }

    public String saveImage(Bitmap myBitmap) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        myBitmap.compress(Bitmap.CompressFormat.JPEG, 90, bytes);
        File wallpaperDirectory = new File(
                Environment.getExternalStorageDirectory() + IMAGE_DIRECTORY);
        // have the object build the directory structure, if needed.
        if (!wallpaperDirectory.exists()) {
            wallpaperDirectory.mkdirs();
        }

        try {
            File f = new File(wallpaperDirectory, Calendar.getInstance()
                    .getTimeInMillis() + ".jpg");
            f.createNewFile();
            FileOutputStream fo = new FileOutputStream(f);
            fo.write(bytes.toByteArray());
            MediaScannerConnection.scanFile(this,
                    new String[]{f.getPath()},
                    new String[]{"image/jpeg"}, null);
            fo.close();
            Log.d("TAG", "File Saved::--->" + f.getAbsolutePath());

            return f.getAbsolutePath();
        } catch (IOException e1) {
            e1.printStackTrace();
        }
        return "";
    }

    public void choosePhotoFromGallaryGym() {
        Intent galleryIntent = new Intent(Intent.ACTION_PICK,
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI);

        startActivityForResult(galleryIntent, GALLERY);
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == this.RESULT_CANCELED) {
            return;
        }
        if (requestCode == GALLERY) {
            if (data != null) {
                Uri contentURI = data.getData();
                try {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(Objects.requireNonNull(this).getContentResolver(), contentURI);
                    imagePathGymProfile = saveImage(bitmap);
                    profileImageGym.setImageBitmap(bitmap);
                } catch (IOException e) {
                    e.printStackTrace();
                    Toast.makeText(this, "Failed!", Toast.LENGTH_SHORT).show();
                }
            }
        } else if (requestCode == CAMERA) {
            Bitmap thumbnail = (Bitmap) Objects.requireNonNull(data.getExtras()).get("data");
            profileImageGym.setImageBitmap(thumbnail);
            assert thumbnail != null;
            imagePathGymProfile = saveImage(thumbnail);
        }
    }

    private void takePhotoFromCameraGym() {
        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(intent, CAMERA);
    }

    @Override
    public void onDestroy() {
        RealmManager.close();
        super.onDestroy();
    }

    private void saveUpdateGymProfile(GymProfileData gymProfileData) {
        RealmManager.recordsDao().updateSaveProfileGym(gymProfileData);
    }
}
