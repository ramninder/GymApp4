package com.example.gym;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;

import butterknife.BindView;
import butterknife.ButterKnife;

public class GymReviewActivity extends AppCompatActivity {

    @BindView(R.id.backBtn)
    RelativeLayout backBtn;
    @BindView(R.id.ivLogo)
    ImageView ivLogo;
    @BindView(R.id.tvPlaceName)
    TextView tvPlaceName;
    @BindView(R.id.tvAddress)
    TextView tvAddress;
    @BindView(R.id.tvRatting)
    TextView tvRatting;
    @BindView(R.id.tvUserRatting)
    TextView tvUserRatting;
    @BindView(R.id.btGym)
    Button btGym;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review_gym);
        ButterKnife.bind(this);
        backBtn.setOnClickListener(view -> finish());
        Log.e("total_user_ratting:", "" + NearByGymGoogleApiActivity.total_user_ratting);
        Log.e("ratting:", "" + NearByGymGoogleApiActivity.ratting);
        Log.e("gymAddress:", "" + NearByGymGoogleApiActivity.gymAddress);
        Log.e("gymName:", "" + NearByGymGoogleApiActivity.gymName);
        Log.e("gymImageUrl:", "" + NearByGymGoogleApiActivity.gymImageUrl);
        Glide.with(this)
                .load(NearByGymGoogleApiActivity.gymImageUrl)
                .into(ivLogo);
        tvPlaceName.setText(NearByGymGoogleApiActivity.gymName);
        tvAddress.setText(NearByGymGoogleApiActivity.gymAddress);
        tvRatting.setText("Rating: " + NearByGymGoogleApiActivity.ratting);
        tvUserRatting.setText("Total User Ratings: " + NearByGymGoogleApiActivity.total_user_ratting);
        btGym.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

    }
}
